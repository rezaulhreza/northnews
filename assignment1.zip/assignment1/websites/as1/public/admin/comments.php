<?php
//Comments are displayed here
$tag = 'Manage Comments';
$heading = 'Approve/Delete Comments';
//call navbar
require 'adminDashNav.php';
require '../super/comments_code.php';
