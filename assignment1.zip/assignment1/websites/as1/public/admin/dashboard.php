<?php

//dashboard file which contains the post details and buttons to edit or delete
$tag = 'Dashboard';
$heading = 'Manage Posts';
//calling nav area for admin panel
require 'adminDashNav.php';
require '../super/dashboard_code.php';
