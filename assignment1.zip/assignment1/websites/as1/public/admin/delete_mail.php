<?php

require '../super/delete_mail.php';
