<?php

//$tag variable here is the title of the page which is set to be printed on the login page for administrator
$tag = 'Admin';

//importing the adminLogin.php which contains the header of the index.php
//within the administrator area
require 'adminLogin.php';
?>

<!-- title for the admin panel -->
<article>
	<h3 align="center"> Administrative Panel </h3>
	<?php
	//the session start function starts the user session data
	session_start();
	//importing the file which contains connection to the database
	require '../connect.php';
	//if submit is clicked below code will run
	if (isset($_POST['submit'])) {
		//setting variables for user name and password
		$username = $_POST['username'];
		$password = $_POST['password'];

		//performing sql queries which will retrieve all the rows and columns from the table admin which contains
		//the information about username and password
		$sql = $pdo->prepare("SELECT * FROM admin WHERE Username = '$username'");
		//this will execute the username variable assigned to the column Username to fetch the information later.
		$sql->execute([$username]);
		//the fetch function will get the result from a set of information
		$results  = $sql->fetch();

		//if the result which is fetched is not empty and contain in the db run this
		if (!empty($results)) {

			//this will verify the plain password entered by the user against the hashed one in the db
			if (password_verify($password, $results['Password'])) {
				//there are tow types of admin
				//The main admin type is Super, has the ability to add or remove admin.
				//if the result matches with the Type Super, it will redirect the user to the super admin panel
				if ($results['Type'] == 'Super') {
					//set the session for the user which indicates user is logged in
					$_SESSION['users'] = $username;
					//redirecting to dashboard for the super admin
					echo '<script> window.location.href="/super/dashboard.php"; </script>';
				}
				//if the user type is not 'Super' then run this
				else {
					//if type is matched as Admin
					if ($results['Type'] == 'Admin') {
						$_SESSION['users'] = $username;
						//redirect to the admin panel of secondary admins
						echo '<script> window.location.href="dashboard.php"; </script>';
					}
				}
			}
			//if it returns 0 but either info is correct print this
			else {
				echo 'ERROR: Incorrect Password!';
			}
		}
		//if any of the input doesn't match print this
		else {
			echo 'ERROR: Incorrect Username or Password!';
		}
	}
	?>

	<!-- form for the admin login -->
	<form method="post" action="">


		<label>Username</label> <input type="text" name="username" placeholder="Username" required />
		<label>Password</label> <input type="password" name="password" placeholder="Password" required />


		<input type="submit" name="submit" value="Login" />
	</form>

	<?php require '../footer.php'; //call the file containing footer
