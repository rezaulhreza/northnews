<?php

require '../super/logout.php';
