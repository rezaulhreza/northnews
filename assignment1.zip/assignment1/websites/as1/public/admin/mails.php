<?php
//php file for mails which are sent from contact us section 
//page title
$tag = 'Mails';
$heading = 'Messages';
//call nav bar
require 'adminDashNav.php';

require '../super/mails_code.php';
