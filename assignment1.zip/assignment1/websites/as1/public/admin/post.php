<?php

//this is for posting articles

//title for front end
$tag = 'Add Post';
$heading = 'Add a new Article';
//call nav bar
require 'adminDashNav.php';
require '../super/post_code.php';
