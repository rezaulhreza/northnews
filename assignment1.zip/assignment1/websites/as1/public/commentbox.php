<hr>
<!-- this is the form for user to comment on articles -->
<h3 align="center"> Add Comment </h3>
<form method="post" action="">



    <label>Comment</label> <textarea name="comment" required></textarea>


    <input type="submit" name="submit" value="Add Comment" />
</form>