<?php
$tag = 'Contact';
//call the navbar
require 'head.php';

//if submit is clicked then run this
if (isset($_POST['submit'])) {
	//pass the name variable to array via post method.
	$name = $_POST['name']; //for input name
	$email = $_POST['email']; //for input email
	$subject = $_POST['subject']; //for input subject
	$message = $_POST['message']; //for input message
	//prepare statement to insert data into database.
	$stm = $pdo->prepare("INSERT INTO mails (ID,Name,Email,Subject,Message,Date) VALUES ( :id, :name,:email,:subject,:message, :date)");
	// inserting a record with an array of insert values
	$stm->execute(array(':id' => NULL, ':name' => $name, ':email' => $email, ':subject' => $subject, ':message' => $message, ':date' => date('Y/m/d')));
	echo "Message sent successfully!";
}
?>
<h3> Contact Us </h3>

<form method="post" action="contact.php">


	<label>Name</label> <input type="text" name="name" placeholder="Name" required />
	<label>Email</label> <input type="email" name="email" placeholder="Email" required />
	<label>Subject</label> <input type="text" name="subject" placeholder="Subject" required />
	<label>Message</label> <textarea name="message" required></textarea>


	<input type="submit" name="submit" value="Send" />
</form>
<?php require 'footer.php';
