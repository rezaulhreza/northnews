</article>
</main>

<footer>
    &copy; Northampton News 2017 <p style="float:right; font-size:10px;">Developed by Rezaul H Reza</p>



</footer>

</body>

</html>