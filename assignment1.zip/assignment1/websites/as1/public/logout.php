<?php

session_start();
//when logged out destroy the session and redirect to home page
session_destroy();

header("location:../../index.php");
