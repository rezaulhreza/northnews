<?php
$tag = 'Search Results';
require 'head.php';
require 'searchbox.php';


if (isset($_POST['submit'])) {
	//same logic as latest.php file
	if (!isset($_GET['id'])) {
		$id = 1;
	} else {
		$id = $_GET['id'];
	}
	$start = 0;
	$limit = 12;
	$start = ($id - 1) * $limit;

	$search = '%' . $_POST['search'] . '%';
	echo '<h2 align="center"> Search Results </h2><br>';
	//sql query using prepared statement 
	//here LIKE operator is used to get any characters containing the desired letter from Title  Anchor or Category
	$sql = $pdo->prepare("SELECT * FROM `posts` WHERE `Title` LIKE ? OR `Anchor` LIKE ? OR `Category` LIKE ? ORDER BY ID DESC");
	//execute the arrays of variables
	$sql->execute([$search, $search, $search]);
	$results  = $sql->fetchAll();
	//counts the all items from the execution
	$rows = count($results);
	//https://stackoverflow.com/questions/37872654/pagination-ceiling-an-array-using-pdo
	$total = ceil($rows / $limit);

	if ($rows < 1) {
		echo 'No result found!';
	} else {

		foreach ($results as $row) {
			//calling the file which has the scripts to display date of posts, inspired from lecture
			require 'date.php';
			//link to readmore.php file which will lead to the page containing details about the articles posted
			echo '<a style="text-decoration:none;color:black;" href="readmore.php?id=' . $row['ID'] . '">';
			//if the query goes through each and every row and finds the image index then run this
			//the directory for the image is admin which contains the folder for image.
			//so this statement will go through that folder and will search the value of that image, if it contains the image
			//it will display the image in below format
			if ($row['Image']) {
				echo '<p align="center"><img src="admin/' . $row['Image'] . '" height="240px" width="50%"></p>';
			}
			//print the title of the post from row called Title and the name of the author
			//after the a href="anchor.php.... it will replace the author name in the url parameter , linked to anchor.php file
			echo '<h3 align="center"> ' . $row['Title'] . '<br></a><span style="font-size:13px;"> By: <a href="anchor.php?anc=' . $row['Anchor'] . '" style="text-decoration:none;color:black;font-size:13px">' . $row['Anchor'] . '</a> </span></h3>
		<br>
							
							<a style="text-decoration:none;color:black;" href="readmore.php?id=' .
				$row['ID'] . '"><p align="justify">' .
				//https://thisinterestsme.com/php-get-first-character-string/
				substr($row['Content'], 0, 40) . '... <i style="color: red;" >Read More</i> </p></a><p align="right">'
				. $d . ' ' . $dc . ', ' . $dy . ' </p><hr>';
		}
		if ($id > 1) {
			echo '<a href="?id=' . $id - 1 . '">Prev </a>';
		}
		if ($id < $total) {
			echo '<a href="?id=' . $id + 1 . '">Next </a>';
		}
	}
}
require 'footer.php';
