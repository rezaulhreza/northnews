	<div align="right">
		<form method="post" action="search_results.php">
			<input type="text" style="float:right" name="search" placeholder="I'm looking for..." />
			<input type="submit" style="float:right;width:70px;" name="submit" value="Search" />
		</form>
	</div><br> <br><br><br><br> <br><br>