<?php
//if submit is clicked run this
if (isset($_POST['submit'])) {
    //call db file
    require '../connect.php';
    //assign variable to array
    $name = $_POST['name'];


    //insert query with pdo prepare statement for category table on db
    $stm = $pdo->prepare("INSERT INTO category (ID,Name,Date) VALUES ( :id, :name, :date)");
    // inserting a record by executing the query
    $stm->execute(array(':id' => NULL, ':name' => $name, ':date' => date('Y/m/d')));
    echo "New Category was added successfully";
}
?>

<form method="post" action="">


    <label>Category Name</label> <input type="text" name="name" placeholder="Category Name" />



    <input type="submit" name="submit" value="Add Category" />
</form>

<?php require '../footer.php';
