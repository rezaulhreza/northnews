<?php
//call the session check file
require 'check.php';
//call db connection file
require '../connect.php';
//set the id variable to array id and pass it to the script through get method
$id = $_GET['id'];
//set status to Approved in the array index
$status = 'Approved';
//update query to update the comment status. if approve button is clicked 
//then this query will execute
$sql = $pdo->prepare("UPDATE `comments` SET `Status`= ? WHERE `SN` = ?");
//execute the prepare statement and particularly run the script 
//it will go through the status and  id and will update the row from pending
//to Approved
$sql->execute([$status, $id]);
//rowcount function will return the rows which was applied by the sql query
$results  = $sql->rowCount();
if (isset($results)) {
	header('location:comments.php');
}
