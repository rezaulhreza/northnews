<?php
//call db file
require '../connect.php';


//set the variable to array Pending which is a column in the comments table
//comments from users are set as pending status
$status = 'Pending';
//select all from comments table using prepared statement
$sql = $pdo->prepare("SELECT * FROM comments ");
//execute the array status where the value is set to pending
$sql->execute([$status]);
//return all the row contains status pending
$results  = $sql->fetchAll();
//if no results are returned print this
if (!$results) {
	echo 'No Pending Comment at the moment!';
} else {
	//if it returns 1 or more print the info in table format
	echo '<table>
					<tr align="center">
						<th> Name </th>
						<th> Comment </th>
						<th> Action </th>
					</tr>
				';
	//go through each and every row and return all the rows stated below and print them
	foreach ($results as $row) {
		echo '<tr align="center">
                                    <td>' . $row['Name'] . '</td>
                                    <td>' . $row['Comment'] . '</td>' . '
                                    <td>';
		if ($row['Status'] == 'Pending') {
			//if status is pending	
			echo '<a style="color: white;background:green;border-radius:1px;text-decoration none;font-size:20px;" href="approve_comment.php?id=' . $row['SN'] . '">Approve     </a>';
		} else {
			//if approved
			echo '<span  style="color: green">Approved    </span>';
		}
		echo '<a style="color: white;background:red;border-radius:1px;text-decoration none;font-size:20px;" href="delete_comment.php?id=' . $row['SN'] . '">     Delete</a></td>
                                </tr>';
	}
}

?>
</table>
<?php require '../footer.php';
