<?php
//dashboard file which contains the post details and buttons to edit or delete
$tag = 'Dashboard';
//calling nav area for admin panel
$heading = 'Manage Posts';
require 'superAdminDashNav.php';
require 'dashboard_code.php';
