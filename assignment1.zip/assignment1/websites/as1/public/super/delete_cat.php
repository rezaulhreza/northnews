<?php
//call session check file
require 'check.php';
///call db file
require '../connect.php';
//set the variable id to array through get method to get the id
$id = $_GET['id'];
//prepare the sql statement
$sql = $pdo->prepare("DELETE FROM category WHERE `ID` = ?");
//execute the sql statement on id
$sql->execute([$id]);
//returns the row affected by the last query and redirect the user to the previous page
$results  = $sql->rowCount();
if (isset($results)) {
    echo "Category  deleted successfully";
    header('location:manage_category.php');
}
