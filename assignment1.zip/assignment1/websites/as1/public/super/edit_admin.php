<?php
$tag = 'Edit Admin';
$heading = 'Edit/Delete Admin';
require 'superAdminDashNav.php';
require 'edit_admin_code.php';
