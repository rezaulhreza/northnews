<?php
$tag = 'Edit Categories';
$heading = "Edit Category";
//call navbar
require 'superAdminDashNav.php';
require 'edit_cat_code.php';
