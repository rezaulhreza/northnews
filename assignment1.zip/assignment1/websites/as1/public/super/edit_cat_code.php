<?php


//call db connect file
require '../connect.php';
//referring the id to URL parameter
$id = $_GET['id'];
//prepare the sql statement to select all from category
$sql = $pdo->prepare("SELECT * FROM category WHERE `ID` = ?");
//return the array id
$sql->execute([$id]);
//fetch the row from the result
$find  = $sql->fetch();

//if submit is clicked run this file
if (isset($_POST['submit'])) {
    //set variable and pass it to post method
    $catName = $_POST['catName'];
    //prepare sql update query for execution
    $sql = $pdo->prepare("UPDATE `category` SET `Name`= ? WHERE `ID` = ?");
    //determining if the update took place or not
    //returns the rows from
    $sql->execute([$catName, $id]);
    $results  = $sql->rowCount();
    if (isset($results)) {
        echo "Record has been successfully updated";
    }
}
?>

<form action="" method="post">
    <label>Name</label> <input type="text" name="catName" placeholder="Category Name" value="<?php echo $find['Name']; ?>" required />
    <input type="submit" name="submit" value="Update" />
</form>

<?php require '../footer.php';
