<?php

$tag = 'Edit Post';
$heading = 'Edit Post Details';

//call navbar
require 'superAdminDashNav.php';
require 'edit_post_code.php';
