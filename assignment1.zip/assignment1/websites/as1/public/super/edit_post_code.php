<?php
//call db connection file
require '../connect.php';
//set variable to id and referring the id to URL parameter using get method
$id = $_GET['id'];
//sql query to select all from posts by id
$sql = "SELECT * FROM posts WHERE `ID` = '$id'";
//execute the statement and fetch the results
$find  = $pdo->query($sql)->fetch();


//if submit is clicked execute this
if (isset($_POST['submit'])) {


    //passing variables to the array using post method
    $title = $_POST['title'];
    $title = str_replace("'", "\'", $title);
    $anchor = $_SESSION['users'];
    $content = $_POST['content'];
    //this will replace single quotes and double quotes as well as backslash 
    // before it was not implemented thus showed error when the post or the title had ''/"'" in it.
    $content = str_replace("'", "\'", $content);
    $category = $_POST['category'];

    //sql update query


    $sql = "UPDATE `posts` SET `Title`= '$title' , `Anchor` = '$anchor' , `Category` = '$category' , `Content` = '$content' WHERE `ID` = '$id'";
    //execute the statement and return the results set of row
    $results  = $pdo->exec($sql);
    //if the query is executed successfully print this
    if (isset($results)) {
        echo "Record has been successfully updated";
    }
}
?>
<form method="post" action="">

    <label>Title</label> <input type="text" name="title" placeholder="Title" value="<?php echo $find['Title']; ?>" required />
    <?php
    //set variable $cat to the html statement as previously it was showing
    //undefined index category
    $cat = '<option>Select Category</option>';
    //sql query to retrieve all data from category table
    $sql = "SELECT * FROM category";
    //go through each results adn get row Name
    foreach ($pdo->query($sql) as $row) {
        //here .= is add to concatenate the variable 
        $cat .= "<option>" . $row['Name'] . "</option>";
    }


    ?>


    <label>Category Name</label> <select name="category" required>

        <?php echo $cat; ?>
    </select>

    <label>Content</label> <textarea name="content"><?php echo $find['Content']; ?></textarea>


    <input type="submit" name="submit" value="Update" />
</form>