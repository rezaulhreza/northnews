<?php

session_start();
//destroy the session and redirect the admin to admin login area
session_destroy();

header("location:/admin/index.php");
