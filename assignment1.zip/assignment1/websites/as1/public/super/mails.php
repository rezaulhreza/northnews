<?php
//php file for mails which are sent from contact us section
//page title
$tag = 'Mails';
$heading = 'Messages';
//call navbar
require 'superAdminDashNav.php';
require 'mails_code.php';
