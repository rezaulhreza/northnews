<?php
//call db connection
require '../connect.php';
//query to fetch all data from table 'mails' in descending order
$sql = "SELECT * FROM mails ORDER BY ID DESC";
//returns the indexes from the query
$results  = $pdo->query($sql)->fetchAll();
//if the result set is less than one print this
if (count($results) < 1) {
	echo 'No Mail sent yet!';
}
//if not then print this
else {
	echo '	<table>
					<tr>
						<th> Name </th>
						<th> Email </th>
						<th> Subject </th>
						<th> Message </th>
					</tr>';
	//go through each and every row and bring these indexes stated below 
	foreach ($pdo->query($sql) as $row) {
		echo '<tr>
									<td>' . $row['Name'] . '</td>
									<td>' . $row['Email'] . '</td>
									<td>' . $row['Subject'] . '</td>
									<td>' . $row['Message'] . '</td>
	<td><a href="delete_mail.php?id=' . $row['ID'] . '">Delete</a></td>
									</tr>'; //delete mail link
	}
}

?>
</table>
<?php
require '../footer.php';
