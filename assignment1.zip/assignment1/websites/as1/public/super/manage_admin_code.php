<?php
//call db file
require '../connect.php';

//set the   type as admin by assigning it to variable
$type = 'Admin';
//prepare the statement to select all from admin table where the type is admin
$sql = $pdo->prepare("SELECT * FROM admin WHERE Type=? ORDER BY ID DESC");
//execute the array $type which has the value 'Admin'
$sql->execute([$type]);
//return the array containing all the results from the sql statement
$results = $sql->fetchAll();
if (count($results) < 1) {
    //if result is less than  print this
    echo 'No Admin added yet!';
} else {
    //if it returns the results as true from the sql statement
    //print this in table format
    echo '	<table>
					<tr>
						<th> Username </th>
						
						<th> Actions </th>
					</tr>';
    //go through each and every row
    foreach ($results as $row) {
        echo '<tr>
									<td>' . $row['Username'] . '</td>
									
									<td> <a href="edit_admin.php?id=' . $row['ID'] . '">Edit</a><a href="delete_admin.php?id=' . $row['ID'] . '">Delete</a></td>
								</tr>'; //links to edit admin and delete admin is added for modifying purposes
    }
} ?>
</table>
<?php require '../footer.php';
