<?php
//manage category file
$tag = 'Manage Categories';
$heading = 'Edit/Delete Categories';
//call the navbar
require 'superAdminDashNav.php';
require 'manage_category_code.php';
